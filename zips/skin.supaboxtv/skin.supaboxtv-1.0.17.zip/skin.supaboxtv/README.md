# skin.confluence.hwy2015

Ported from Confluence v2.5.9 used on Helix 14.0 stable.

It is meant for use with Helix (at least 14.0 stable) 
and will not work on Gotham, Frodo or earlier versions.


25 shortcuts for videos, 10 for the rest.  Debug graph 
included.  This skin may be a work in progress, but aims 
to bring useful customizations while holding onto the 
main feel of it's pretacessor, Confluence.

