plugin.video.nfl-teams
=======================

XBMC addon showing videos from NFL teams


Other NFL related addons
------------------------
* [plugin.video.nfl.com](https://github.com/divingmule/plugin.video.nfl.com)  
  An addon to play videos from the [NFL.com](http://www.nfl.com/) website.
* [plugin.video.nfl.gamepass](https://github.com/Alexqw/xbmc-gamepass)  
  An addon for playing games via NFL Game Pass.
